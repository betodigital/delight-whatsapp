(function($) {
    'use strict';

    $(document).ready(function() {
        $('.delight-whatsapp').on('click', function() {
            // Você pode adicionar análises ou outras funcionalidades aqui
            console.log('WhatsApp button clicked');
        });
    });

})(jQuery);